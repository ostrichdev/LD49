using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AdvancedSpikeBehaviour : MonoBehaviour
{
    public bool loop;
    public bool prox;
    public bool invisible;

    public float variable;
    public bool loopStart;

    Animator anim;
    PlayerController pc;

    void Start()
    {
        anim = GetComponent<Animator>();
        pc = FindObjectOfType<PlayerController>();

        if (loop) 
        {
            StartCoroutine(WaitTime());
        }
    }

    void Update()
    {
        if (prox) 
        {
            if (Vector2.Distance(pc.transform.position, transform.position) <= variable)
            {
                anim.SetBool("active", true);
            }
            else 
            {
                anim.SetBool("active", false);
            }
        }
        else if (invisible) 
        {
            if (Vector2.Distance(pc.transform.position, transform.position) > variable)
            {
                anim.SetBool("active", true);
            }
            else
            {
                anim.SetBool("active", false);
            }
        }
    }

    IEnumerator WaitTime() 
    {
        anim.SetBool("active", loopStart);

        yield return new WaitForSeconds(variable);

        anim.SetBool("active", !loopStart);

        yield return new WaitForSeconds(variable);

        StartCoroutine(WaitTime());
    }
}
