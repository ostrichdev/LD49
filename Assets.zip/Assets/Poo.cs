using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Poo : MonoBehaviour
{
    public GameObject contactNoise;

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 6 || collision.gameObject.layer == 7) 
        {
            Instantiate(contactNoise, transform.position, Quaternion.identity);
        }
    }
}
