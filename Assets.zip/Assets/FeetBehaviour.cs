using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FeetBehaviour : MonoBehaviour
{
    PlayerController pc;

    bool touchingGround;

    void Start()
    {
        pc = transform.parent.GetComponent<PlayerController>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 6)
        {
            touchingGround = true;
            pc.GroundState(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 6)
        {
            touchingGround = false;
            pc.GroundState(false);
        }
    }
}
