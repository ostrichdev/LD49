using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed;
    public float speedLimit;

    public float jumpPower;
    public float gravity;

    public LayerMask mask;

    float xVelocity;
    float yVelocity;

    public bool onGround;

    public float angleMax;
    public float anglePS;

    public float angle;

    public GameObject sprite;

    public GameObject jumpNoise;

    public void GroundState(bool state) 
    {
        onGround = state;

        if (state == true) 
        {
            yVelocity = 0;
        }
    }

    void Update()
    {
        RaycastHit2D downHit = Physics2D.Raycast(transform.position, Vector2.down, 0.1f, mask);

        if (downHit.collider != null)
        {
            if (downHit.collider.gameObject.layer == 7)
            {
                transform.parent = downHit.collider.transform;
            }
            else 
            {
                transform.parent = null;
            }

            if (onGround == false) 
            {
                yVelocity = 0;
            }

            onGround = true;
        }
        else 
        {
            onGround = false;
            transform.parent = null;
        }

        RaycastHit2D upHit = Physics2D.Raycast(transform.position, Vector2.up, 1.51f, mask);

        if (upHit.collider != null)
        {
            yVelocity = 0;
        }


        if (onGround)
        {
            if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.UpArrow)) 
            {
                onGround = false;

                Instantiate(jumpNoise, transform.position, Quaternion.identity);
                yVelocity += jumpPower;
            }
        }
        else 
        {
            yVelocity -= Time.deltaTime * gravity;
        }

        //movement
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            RaycastHit2D hit = Physics2D.Raycast(new Vector2(transform.position.x, transform.position.y + 0.5f), Vector2.left, 0.5f, mask);

            if (hit.collider == null)
            {
                xVelocity -= speed * Time.deltaTime;

                if (xVelocity > 0)
                {
                    xVelocity -= speed * Time.deltaTime * 2f;
                }

                if (angle + anglePS * Time.deltaTime >= angleMax)
                {
                    angle = angleMax;
                }
                else
                {
                    angle += anglePS * Time.deltaTime;
                }
            }
            else 
            {
                xVelocity = 0;
            }
        }

        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            RaycastHit2D hit = Physics2D.Raycast(new Vector2(transform.position.x, transform.position.y + 0.5f), Vector2.right, 0.5f, mask);

            if (hit.collider == null)
            {
                xVelocity += speed * Time.deltaTime;

                if (xVelocity < 0)
                {
                    xVelocity += speed * Time.deltaTime * 2f;
                }

                if (angle - anglePS * Time.deltaTime <= -angleMax)
                {
                    angle = -angleMax;
                }
                else
                {
                    angle -= anglePS * Time.deltaTime;
                }
            }
            else
            {
                xVelocity = 0;
            }
        }

        if (!Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.LeftArrow) && !Input.GetKey(KeyCode.RightArrow))
        {
            if (xVelocity < 0) 
            {
                xVelocity += speed * Time.deltaTime * 2f;
                if (xVelocity >= 0) 
                {
                    xVelocity = 0;
                }
            }

            if (xVelocity > 0)
            {
                xVelocity -= speed * Time.deltaTime * 2f;
                if (xVelocity <= 0)
                {
                    xVelocity = 0;
                }
            }

            if (angle < 0)
            {
                angle += anglePS * Time.deltaTime;
                if (angle >= 0)
                {
                    angle = 0;
                }
            }

            if (angle > 0)
            {
                angle -= anglePS * Time.deltaTime;
                if (angle <= 0)
                {
                    angle = 0;
                }
            }
        }


        xVelocity = Mathf.Clamp(xVelocity, -speedLimit, speedLimit);
        //yVelocity = Mathf.Clamp(yVelocity, -0.1f, 0.1f);        

        sprite.transform.eulerAngles = new Vector3(0, 0, angle);
        transform.position += new Vector3(xVelocity * Time.deltaTime, yVelocity * Time.deltaTime, 0);
    }
}
