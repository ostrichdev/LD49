using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatformBehaviour : MonoBehaviour
{
    public Vector2 pointA;
    public Vector2 pointB;

    public float speed;
    public bool grid;

    public bool movingToA;

    void Start()
    {
        
    }

    void Update()
    {
        if (grid)
        {
            if (movingToA)
            {
                if (transform.position.y != pointA.y)
                {
                    transform.position = Vector2.MoveTowards(transform.position, new Vector2(transform.position.x, pointA.y), speed * Time.deltaTime);
                }
                else if (transform.position.x != pointA.x)
                {
                    transform.position = Vector2.MoveTowards(transform.position, new Vector2(pointA.x, transform.position.y), speed * Time.deltaTime);
                }
                else
                {
                    movingToA = false;
                }
            }
            else
            {
                if (transform.position.y != pointB.y)
                {
                    transform.position =  Vector2.MoveTowards(transform.position, new Vector2(transform.position.x, pointB.y), speed * Time.deltaTime);
                }
                else if (transform.position.x != pointB.x)
                {
                    transform.position = Vector2.MoveTowards(transform.position, new Vector2(pointB.x, transform.position.y), speed * Time.deltaTime);
                }
                else
                {
                    movingToA = true;
                }
            }
        }
        else 
        {
            if (movingToA)
            {
                if (transform.position != (Vector3)pointA)
                {
                    transform.position = Vector2.MoveTowards(transform.position, pointA, speed * Time.deltaTime);
                }
                else 
                {
                    movingToA = false;
                }
            }
            else
            {
                if (transform.position != (Vector3)pointB)
                {
                    transform.position = Vector2.MoveTowards(transform.position, pointB, speed * Time.deltaTime);
                }
                else
                {
                    movingToA = true;
                }
            }

        }
    }
}
