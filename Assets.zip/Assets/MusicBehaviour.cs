using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicBehaviour : MonoBehaviour
{
    public GameObject dieNoise;

    bool muted;

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M)) 
        {
            muted = !muted;
        }

        if (Input.GetKeyDown(KeyCode.Escape)) 
        {
            Application.Quit();
        }

        if (muted)
        {
            GetComponent<AudioSource>().volume = 0;
        }
        else 
        {
            GetComponent<AudioSource>().volume = 0.15f;
        }
    }
}
