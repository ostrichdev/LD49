using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyTime : MonoBehaviour
{
    public float time;

    void Start()
    {
        DontDestroyOnLoad(gameObject);

        StartCoroutine(DestroyTimer());
    }

    IEnumerator DestroyTimer() 
    {
        yield return new WaitForSeconds(time);

        Destroy(gameObject);
    }
}
