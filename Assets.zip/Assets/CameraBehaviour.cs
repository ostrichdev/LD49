using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraBehaviour : MonoBehaviour
{
    public Transform subject;

    public bool lockY;
    public float yPos;

    public float yOffset;

    [Space]

    public bool lockX;
    public float xPos;

    public float xOffset;

    private void Start()
    {
        //subject = FindObjectOfType<PlayerController>().transform;
    }

    void Update()
    {
        float x = subject.position.x;
        float y = subject.position.y;

        if (lockX)
        {
            x = xPos;
        }

        if (lockY) 
        {
            y = yPos;
        }

        transform.position = new Vector3(x + xOffset, y + yOffset, -10f);
    }
}
