using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour
{
    public float rotSpeed;

    void Update()
    {
        transform.eulerAngles += new Vector3(0, 0, rotSpeed * Time.deltaTime);
    }
}
